#!/bin/bash

set -e

export MCPI_MODE="server"
export USER_UID="$(id -u)"
export USER_GID="$(id -g)"

echo "Changing current directory..."
cd /mnt/server
echo "Done!"

echo "Preparing logs..."
touch main.log
tail -f main.log &
TAIL_PID=$!
echo "Done!"

echo "Starting game..."
./launcher >> main.log
echo "Stopped game."

kill -9 $TAIL_PID
