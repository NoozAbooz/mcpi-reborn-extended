#!/bin/bash

set -e

export MCPI_MODE="server"
export USER_UID="$(id -u)"
export USER_GID="$(id -g)"

echo "Preparing tmp folder..."
rm -rf /tmp/minecraft-pi
mkdir -p /tmp/minecraft-pi
echo "Done!"

echo "Preparing logs..."
touch /tmp/minecraft-pi/main.log
tail -f /tmp/minecraft-pi/main.log &
TAIL_PID=$!
echo "Done!"

echo "Changing current directory..."
cd /app/minecraft-pi
echo "Done!"

export MCPI_ROOT="${PWD}"

echo "Starting game..."
./launcher
echo "Stopped game."

kill -9 $TAIL_PID
