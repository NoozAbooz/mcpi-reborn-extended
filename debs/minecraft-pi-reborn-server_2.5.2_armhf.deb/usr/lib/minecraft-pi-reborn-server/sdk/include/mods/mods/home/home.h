#pragma once

#ifdef __cplusplus
extern "C" {
#endif

char *home_get();

#ifdef __cplusplus
}
#endif
