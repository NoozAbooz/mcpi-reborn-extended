#pragma once

#ifdef __cplusplus
extern "C" {
#endif

extern unsigned char *cursed_chest;

#ifdef __cplusplus
}
#endif