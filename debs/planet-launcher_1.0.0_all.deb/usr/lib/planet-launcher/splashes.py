SPLASHES = [
    "The moon is not a planet",
    "Pluto = Planet",
    "Ayy Yep!",
    "What's my purpose?",
    "MCPI_SPEEDHACK",
    "MCPIL-Revival",
    "Minescripters",
    "I use Planet BTW",
    "Snowball",
    "Robo",
    "If I could, I would. But I can't, so I shan't.",
]
