#pragma once

#define MCPI_SERVER_MODE
#define MCPI_HEADLESS_MODE
#define MCPI_IS_APPIMAGE_BUILD
/* #undef MCPI_USE_PREBUILT_ARMHF_TOOLCHAIN */
/* #undef MCPI_USE_GLES1_COMPATIBILITY_LAYER */
#define MCPI_APP_TITLE "MCPI-Reborn Extended (Server)"
#define MCPI_APP_ID "com.nooz.MCPIRebornExtendedServer"
#define MCPI_VERSION "2.4.3-4"
#define MCPI_SDK_DIR "lib/minecraft-pi-reborn-server/sdk"
