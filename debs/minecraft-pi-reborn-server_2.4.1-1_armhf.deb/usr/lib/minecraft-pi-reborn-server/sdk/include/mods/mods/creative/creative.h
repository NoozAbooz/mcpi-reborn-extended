#pragma once

#ifdef __cplusplus
extern "C" {
#endif

int creative_is_restricted();

#ifdef __cplusplus
}
#endif
