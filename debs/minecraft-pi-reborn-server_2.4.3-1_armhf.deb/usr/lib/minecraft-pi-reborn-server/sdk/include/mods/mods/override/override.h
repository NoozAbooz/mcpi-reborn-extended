#pragma once

#ifdef __cplusplus
extern "C" {
#endif

char *override_get_path(const char *filename);

#ifdef __cplusplus
}
#endif
