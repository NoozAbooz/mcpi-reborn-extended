#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void sign_key_press(char key);

#ifdef __cplusplus
}
#endif
